#include <stdio.h>
#include <stdlib.h>

void printMatrix(int**);
void solve(int**);
void traverseSubGrid(int**, int, int);
void update(int**, int, int , int);
int loop(int**);

void printMatrix(int **matrix){
	int i, x;
	for(i = 0; i < 9; i++){
		for(x = 0; x < 9; x++){
			printf("%d\t", matrix[i][x]);
		}
		printf("\n");
	}
}

void solve(int **matrix){
	int row, column, i, x;
	row = 0;
	column = 0;
	for(i = 0; i < 3; i++){
		for(x = 0; x < 3; x++){
			traverseSubGrid(matrix, row, column);
			column = column + 3;
		}
		row = row + 3;
		column = 0;
	}	
}

void traverseSubGrid(int **matrix, int row, int column){
	int i = 0;
	int x = 0;
	int d = 1;
	int boolean = 0;
	while(d < 10){
		for(i = row; i < row + 3; i++){
			for(x = column; x < column + 3; x++){
				if(matrix[i][x] == d){
					boolean = 1;
				}else{
					
				}
			}
		}
		if(boolean == 0){
			update(matrix, row, column, d);
		}
		boolean = 0;
		d++;
	}	
}

void update(int **matrix, int row, int column, int value){
	int *array;
	array = (int *)malloc(sizeof(int)*10);
	int *array1;
	array1 = (int *)malloc(sizeof(int)*10);
	int m;
	for(m = 0; m < 10; m++){
		array[m] = -1;
		array1[m] = -1;
	}
	// find number of empty spots
	int i, x, e, d;
	int f = 0;
	int g = 0;
	int count = 0;
	for(i = row; i < row + 3; i++){
		for(x = column; x < column + 3; x++){
			if(matrix[i][x] == 0){
				count++;
			}
		}
	}
	//printf("Number of empty spots: %d\n", count);
	
	//printf("Number of empty spots in sub matrix: %d\n", count);
	// iterate through whole matrix to find all other values and what rows and columns they are in
	for(i = 0; i < 9; i++){
		for(x = 0; x < 9; x++){
			if(matrix[i][x] == value){
				if((i >= row) && (i < row + 3)){
					// value is in the same row. eliminate empty slots
					for(e = column; e < column + 3; e++){
						if(matrix[i][e] == 0){
							int test;
							int boolean3 = 0;
							for(test = 0; test < 10; test++){
								if(array1[test] == e){
									boolean3 = 1;
								}
							}
							if(boolean3 == 0){
								array[f] = i;
								f++;
								count--;
							}
							
						}
					}
				}
				else if((x >= column) && (x < column + 3)){
					// value is in the same column. eliminate empty slots
					for(d = row; d < row + 3; d++){
						if(matrix[d][x] == 0){
							int test;
							int boolean3 = 0;
							for(test = 0; test < 10; test++){
								if(array[test] == d){
									boolean3 = 1;
								}
							}
							if(boolean3 == 0){
								array1[g] = x;
								g++;
								count--;
							}
						}
					}
				}
			}
		}
	}
	int hold = 0;
	int j;
	if(count < 2){
		for(i = row; i < row + 3; i++){
			for(x = column; x < column + 3; x++){
				if(matrix[i][x] == 0){
					for(j = 0; j < 10; j++){
						if(array[j] == i){
							hold = 1;
						}
						if(array1[j] == x){
							hold = 1;
						}
					}
					if(hold == 0){
						matrix[i][x] = value;
					}
					
				}else{

				}
				hold = 0;
			}	
		}
	}
}

int loop(int **matrix){
	int i, x;
	int count = 0;
	for(i = 0; i < 9; i++){
		for(x = 0; x < 9; x++){
			if(matrix[i][x] == 0){
				count++;
			}
		}
	}
	return count;
}

int main(int argc, char** argv){
	if(argc != 2){
		printf("not enough arguments\n");
		return 0;
 	}

	FILE *fp;
	fp = fopen(argv[1], "r");

	if(fp == NULL){
		return 0;
	}

	int i;
	int **matrix;
	matrix = malloc(sizeof(int*)*9);
	for(i = 0; i < 9; i++){
		matrix[i] = malloc(sizeof(int)*9);
	}
	
	int x;
	int count = 0;
	for(i = 0; i < 9; i++){
		for(x = 0; x < 9; x++){
			fscanf(fp, "%d", &matrix[i][x]);
			if(matrix[i][x] == 0){
				count++;
			}
		}
	}
	fclose(fp);
	count = loop(matrix);
	int testing;
	while(count != 0){
		testing = count;
		solve(matrix);
		count = loop(matrix);
		if(count == testing){
			printf("no-solution");
			return 0;
		}
	}
	printMatrix(matrix);
	return 0;
	
	
}
