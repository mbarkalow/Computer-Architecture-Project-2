#include <stdio.h>
#include <stdlib.h>

void printMatrix(double**, int, int);
void transpose(double**, double**, int, int);
void multiply(double**, double**, double**, int, int, int, int);
void inverse(double**, double **, int, int);
void rowOperation(double**, int, int, int, int, int);

void printMatrix(double **matrix, int n, int m){
	int i, x;
	for(i = 0; i < n; i++){
		for(x = 0; x < m; x++){
			printf("%lf  ", matrix[i][x]);
		}
		printf("\n");
	}
}

void transpose(double **matrix, double **matrixT, int n, int m){
	int i, x;
	for(i = 0; i < m; i++){
		for(x = 0; x < n; x++){
			matrixT[i][x] = matrix[x][i];
		}
	}	
}

void multiply(double **matrix1, double **matrix2, double **resultMatrix, int n, int m, int d, int e){
	double product;
	double sum = 0;
	int i, x, p;
	for(i = 0; i < n; i++){
		//printf("TESTING FOR ERROR");
		for(x = 0; x < e; x++){
				
			for(p = 0; p < m; p++){
				product = (matrix1[i][p]) * (matrix2[p][x]);
				sum = sum + product;
				//printf("Product of two ints: %d\n", numToAdd);
				//storeArray[p] = numToAdd;
			}
			resultMatrix[i][x] = sum;
			sum = 0;
		}
	}
}

void inverse(double **matrix, double **resultMatrix, int n, int m){
	int i, x;
	double **augMatrix;
	augMatrix = malloc(sizeof(double*)*n);
	for(i = 0; i < m; i++){
		augMatrix[i] = malloc(sizeof(double)*(2 * n));
	}
	
	for(i = 0; i < n; i++){
		for(x = 0; x < n; x++){
			augMatrix[i][x] = matrix[i][x];
		}
	}
	
	for(i = 0; i < n; i++){
		for(x = m; x < (2 * m); x++){
			augMatrix[i][x] = 0;
		}
	}
	int h = 0;
	for(x = m; x < (2 * m); x++){
		augMatrix[h][x] = 1;
		h++;
	}
	//printf("Augmented matrix:\n\n");
	//printMatrix(augMatrix, n, (2 * n));
	
	//int stop = 1;
	x = 0;
	i = 0;
	while(i < n){
		if(i == x){
			if(augMatrix[i][x] != 1.0){
				//printf("Testing inverse function.\n");
				rowOperation(augMatrix, n, n, i, x, 1);
			}
			i++;
			x = 0;
		}else{
			if(augMatrix[i][x] != 0.0){
				//printf("Testing inverse function1.\n");
				rowOperation(augMatrix, n, n, i, x, 0);
			}
			x++;
		}
	}
	
	i = n - 1;
	x = m - 1;
	
	while(i > -1){
		//printf("Current position: %d / %d\n", i, x);
		if(i == x){
			i--;
			x = m - 1;
		}else{
			if(augMatrix[i][x] != 0.0){
				rowOperation(augMatrix, n, n, i, x, 0);
			}
			x--;
		}
	}
	
	//printf("\n");
	//printf("Inverted Matrix: \n\n");
	for(i = 0; i < n; i++){
		for(x = 0; x < (2 * m); x++){
			//printf("%lf   ", augMatrix[i][x]);
		}
		//printf("\n");
	}
	int x1 = 0;
	for(i = 0; i < n; i++){
		for(x = m; x < (2 * m); x++){
			resultMatrix[i][x1] = augMatrix[i][x];
			x1++;
		}
		x1 = 0;
	}
	
	
}

void rowOperation(double **augMatrix, int n, int m, int i, int x, int value){
	double temp;
	int hold = x;
	//int hold1 = i;
	int d, e;
	//double quotient;
	if(value == 1){
		//printf("Testing row operations function.\n");
		if(augMatrix[i][x] == 0){
			
		}else{
			temp = augMatrix[i][x];
			augMatrix[i][x] = temp/temp;
			for(e = 0; e < (2 * m); e++){
				if(e != hold){
					augMatrix[i][e] = augMatrix[i][e]/temp;
				}
			}
			return;
		}
	}
	if(value == 0){
		//printf("Testing row operations function.\n");
		temp = augMatrix[i][x];
		//int iterate;
		e = x;
		for(d = 0; d < n; d++){
			if(d == e){
				if(augMatrix[d][e] == 1){
					double *array = malloc(sizeof(double*)*(2 * m));
					int row = d;
					int f;
					/*if((((temp) * (augMatrix[d][e])) - augMatrix[i][x]) != 0){
						for(f = 0; f < m; f++){
							array[f] = temp*(augMatrix[row][f]);
						}
						for(f = 0; f < m; f++){
							augMatrix[i][f] = (array[f]) + (augMatrix[i][f]);
						}
					}else{*/
						for(f = 0; f < (2 * m); f++){
							array[f] = temp*(augMatrix[row][f]);
						}
						for(f = 0; f < (2 * m); f++){
							//augMatrix[i][f] = (array[f]) - (augMatrix[i][f]);
							augMatrix[i][f] = (augMatrix[i][f] - array[f]);
						}
						return;
					//}
					
					
				}
				
			}
		}
		/*for(iterate = 0; iterate < m; iterate++){
		int f;
			if(i == iterate){
				if(augMatrix[i][iterate] != 1.0){
					for(f = 0; f < m; f++){
						augMatrix[i][f] = augMatrix[i][f] * -1;
					}
					return;
				}
			}
		}*/
				//return;
	}
}

int main(int argc, char** argv){
	if(argc != 3){
		printf("not enough arguments\n");
		return 0;
 	}

	FILE *fp;
	fp = fopen(argv[1], "r");

	if(fp == NULL){
		return 0;
	}
	int n, m, i;
	
	fscanf(fp, "%d", &m);
	fscanf(fp, "%d", &n);
	m = m + 1;
	
	double **matrixX;
	double **matrixY;
	matrixX = malloc(sizeof(double*)*n);
	for(i = 0; i < n; i++){
		matrixX[i] = malloc(sizeof(double)*m);
	}
	double **matrixXcpy;
	matrixXcpy = malloc(sizeof(double*)*n);
	for(i = 0; i < n; i++){
		matrixXcpy[i] = malloc(sizeof(double)*(m + 1));
	}	
	
	matrixY = malloc(sizeof(double*)*n);
	for(i = 0; i < n; i++){
		matrixY[i] = malloc(sizeof(double)*1);
	}
	
	
	int e = 0;
	
	for(i = 0; i < n; i++){
		//matrixX[i][e] = 1;
		matrixXcpy[i][e] = 1;
	}

	char hold;
	//int test;
	//fscanf(fp, "%lf", &matrixX[0][1]);
	for(i = 0; i < n; i++){
		for(e = 1; e < m + 1; e++){
			fscanf(fp, "%lf%c\n", &matrixXcpy[i][e], &hold);
			//printf("hold value: %d\n", hold);
			//printf("test value: %d\n", test);
		}
			
		//count = 0;
	}
	fclose(fp);
	for(i = 0; i < n; i++){
		for(e = 0; e < m; e++){
			matrixX[i][e] = matrixXcpy[i][e];
		}
	}
	for(i = 0; i < n; i++){
		matrixY[i][0] = matrixXcpy[i][m];
	}
	
	double **matrixXT;
	matrixXT = malloc(sizeof(double*)*m);
	for(i = 0; i < m; i++){
		matrixXT[i] = malloc(sizeof(double)*n);
	}
	//printMatrix(matrixX, n, m);
	transpose(matrixX, matrixXT, n, m);
	//printf("Transpose matrix:\n\n");
	//printMatrix(matrixXT, m, n);
	double **XmultXT;
	XmultXT = malloc(sizeof(double*)*m);
	for(i = 0; i < m; i++){
		XmultXT[i] = malloc(sizeof(double)*m);
	}
	multiply(matrixXT, matrixX, XmultXT, m, n, n, m);
	//printf("Result matrix: \n\n");
	//printMatrix(XmultXT, m, m);
	double **resultInverse;
	resultInverse = malloc(sizeof(double*)*m);
	for(i = 0; i < m; i++){
		resultInverse[i] = malloc(sizeof(double)*m);
	}
	inverse(XmultXT, resultInverse, m, m);
	//printf("\nInverted Matrix:\n\n");
	//printMatrix(resultInverse, m, m);
	double **InverseXT;
	InverseXT = malloc(sizeof(double*)*m);
	for(i = 0; i < m; i++){
		InverseXT[i] = malloc(sizeof(double)*n);
	}
	multiply(resultInverse, matrixXT, InverseXT, m, m, m, n);
	//printf("\nInverseXT matrix:\n\n");
	//printMatrix(InverseXT, m, n);
	//printf("\nmatrixY:\n\n");
	//printMatrix(matrixY, n, 1);
	double **weights;
	weights = malloc(sizeof(double*)*m);
	for(i = 0; i < m; i++){
		weights[i] = malloc(sizeof(double)*1);
	}
	multiply(InverseXT, matrixY, weights, m, n, n, 1);
	//printf("\nweights matrix:\n\n");
	//printMatrix(weights, m, 1);
	
	FILE *fp1;
	fp1 = fopen(argv[2], "r");

	if(fp1 == NULL){
		return 0;
	}
	double **testX;
	int rows;
	fscanf(fp1, "%d", &rows);
	testX = malloc(sizeof(double*)*rows);
	for(i = 0; i < rows; i++){
		testX[i] = malloc(sizeof(double)*m);
	}
	e = 0;
	for(i = 0; i < rows; i++){
		testX[i][e] = 1;
	}
	
	for(i = 0; i < rows; i++){
		for(e = 1; e < m; e++){
			fscanf(fp1, "%lf%c\n", &testX[i][e], &hold);
		}
	}
	double **testY;
	testY = malloc(sizeof(double*)*rows);
	for(i = 0; i < rows; i++){
		testY[i] = malloc(sizeof(double)*1);
	}
	//printf("\nTest case X matrix:\n\n");
	//printMatrix(testX, rows, m);
	multiply(testX, weights, testY, rows, m, m, 1);
	//printf("\nHouse prices Y matrix:\n\n");
	//int col;
	for(i = 0; i < rows; i++){
		printf("%0.0lf\n", testY[i][0]);	
	}
	//printMatrix(testY, rows, 1);
	
	/*
	double **testingMatrix;
	testingMatrix = malloc(sizeof(double*)*3);
	for(i = 0; i < 3; i++){
		testingMatrix[i] = malloc(sizeof(double)*3);
	}
	double **testingResult;
	testingResult = malloc(sizeof(double*)*3);
	for(i = 0; i < 3; i++){
		testingResult[i] = malloc(sizeof(double)*3);
	}
	
	FILE *fp2;
	fp2 = fopen(argv[3], "r");
	if(fp2 == NULL){
		return 0;
	}
	int x;
	for(i = 0; i < 3; i++){
		for(x = 0; x < 3; x++){
			fscanf(fp2, "%lf", &testingMatrix[i][x]);
		}
	}
	inverse(testingMatrix, testingResult, 3, 3);*/
	
	return 0;
}
